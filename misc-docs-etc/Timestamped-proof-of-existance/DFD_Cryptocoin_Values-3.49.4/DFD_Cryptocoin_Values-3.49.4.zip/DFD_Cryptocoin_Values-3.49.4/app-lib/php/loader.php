<?php
/*
 * Copyright 2014-2019 GPLv3, DFD Cryptocoin Values by Mike Kilday: http://DragonFrugal.com
 */
 
require_once("app-lib/php/functions/general.php");
require_once("app-lib/php/functions/asset-data.php");
require_once("app-lib/php/functions/exchange-ticker-apis.php");
require_once("app-lib/php/functions/other-apis.php");


?>