#!/bin/bash

# Copyright 2014-2019 GPLv3, DFD Cryptocoin Values by Mike Kilday: http://DragonFrugal.com


######################################

echo " "

if [ "$EUID" -ne 0 ]; then 
 echo "Please run as root (or sudo)."
 echo "Exiting..."
 exit
fi


######################################


# Get date
DATE=$(date '+%Y-%m-%d')


# Get the host ip address
IP=`/bin/hostname -I` 


# Get the operating system and version
if [ -f /etc/os-release ]; then
    # freedesktop.org and systemd
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
elif type lsb_release >/dev/null 2>&1; then
    # linuxbase.org
    OS=$(lsb_release -si)
    VER=$(lsb_release -sr)
elif [ -f /etc/lsb-release ]; then
    # For some versions of Debian/Ubuntu without lsb_release command
    . /etc/lsb-release
    OS=$DISTRIB_ID
    VER=$DISTRIB_RELEASE
elif [ -f /etc/debian_version ]; then
    # Older Debian/Ubuntu/etc.
    OS=Debian
    VER=$(cat /etc/debian_version)
elif [ -f /etc/SuSe-release ]; then
    # Older SuSE/etc.
    ...
elif [ -f /etc/redhat-release ]; then
    # Older Red Hat, CentOS, etc.
    ...
else
    # Fall back to uname, e.g. "Linux <version>", also works for BSD, etc.
    OS=$(uname -s)
    VER=$(uname -r)
fi


######################################

			
echo "Enter the FULL SYSTEM PATH to the document root of the web server:"
echo "(this does NOT automate setting apache's document root, you would need to do that manually)"
echo "(leave blank / hit enter to use the default value: /var/www/html)"
echo " "

read DOC_ROOT
        
if [ -z "$DOC_ROOT" ]; then
DOC_ROOT=${1:-/var/www/html}
echo "Using default website document root:"
echo "$DOC_ROOT"
else
echo "Using custom website document root:"
echo "$DOC_ROOT"
fi

echo " "

if [ ! -d "$DOC_ROOT" ] && [ "$DOC_ROOT" != "/var/www/html" ]; then
echo "The custom document root directory '$DOC_ROOT' does not exist yet."
echo "Please create this directory structure before running this script."
echo "Exiting..."
exit
fi


######################################


echo "TECHNICAL NOTE:"
echo "This script was designed to install / setup on the Raspbian operating system,"
echo "and was developed / created on Raspbian Linux v10, for Raspberry Pi computers."
echo " "

echo "Your operating system has been detected as:"
echo "$OS v$VER"
echo " "

echo "This script may work on other Debian-based systems as well, but it has not been tested for that purpose."
echo "If you already have unrelated web site files located at $DOC_ROOT on your system, they may be affected."
echo "Please back up any important pre-existing files in that directory before proceeding."
echo " "

if [ -f "/etc/debian_version" ]; then
echo "Your system has been detected as Debian-based, which is compatible with this automated installation script."
echo "Continuing..."
echo " "
else
echo "Your system has been detected as NOT BEING Debian-based. Your system is NOT compatible with this automated installation script."
echo "Exiting..."
exit
fi
				
				
if [ -f $DOC_ROOT/config.php ]; then
echo "A configuration file from a previous install of DFD Cryptocoin Values has been detected on your system."
echo "During this upgrade / re-install, it will be backed up to:"
echo "$DOC_ROOT/config.php.BACKUP.$DATE.[random string]"
echo "This will save any custom settings within it."
echo "You will need to manually move any custom settings in this backup file to the new config.php file with a text editor."
echo " "
fi
  				
  				
echo "Select 1 or 2 to choose whether to continue, or quit."
echo " "

OPTIONS="continue quit"

select opt in $OPTIONS; do
        if [ "$opt" = "continue" ]; then
        echo " "
        echo "Continuing with setup..."
        break
       elif [ "$opt" = "quit" ]; then
        echo " "
        echo "Exiting setup..."
        exit
        break
       fi
done

echo " "



######################################


echo " "

echo "Making sure your system is updated before installation..."

echo " "
			
/usr/bin/sudo /usr/bin/apt-get update

#DO NOT RUN dist-upgrade, bad things can happen, lol
/usr/bin/sudo /usr/bin/apt-get upgrade -y

echo " "
				
echo "System update completed."
				
sleep 3
				
echo " "


######################################


echo "Select 1 or 2 to choose whether to install the PHP web server, or skip."
echo " "

OPTIONS="install_webserver skip"

select opt in $OPTIONS; do
        if [ "$opt" = "install_webserver" ]; then
         
         echo " "
			
			echo "Proceeding with PHP web server installation..."
			
			echo " "
			
			/usr/bin/apt-get install apache2 php php-curl php-gd php-zip libapache2-mod-php openssl ssl-cert -y
			
			sleep 3
			
			echo " "
			
			mv -v $DOC_ROOT/index.html $DOC_ROOT/index.php



			######################################
			

			# SSL / Rewrite setup
			
			echo " "
			
			# Regenerate new self-signed SSL cert keys with ssl-cert (for secure HTTPS web pages)
			/usr/sbin/make-ssl-cert generate-default-snakeoil --force-overwrite

			echo "New SSL certificate keys self-generated..."
			echo " "

			# Enable SSL (for secure HTTPS web pages)
			/usr/sbin/a2enmod ssl
			/usr/sbin/a2ensite default-ssl
			
			echo " "

			# Enable mod-rewrite, for upcoming REST API features
			/usr/sbin/a2enmod rewrite
			
			echo " "
				
				if [ -f /etc/init.d/apache2 ]; then
				echo "Mod-rewrite and SSL (for secure HTTPS web pages) have been enabled,"
				echo "restarting the Apache web server..."
				/etc/init.d/apache2 restart
				echo " "
				else
				echo "Mod-rewrite and SSL (for secure HTTPS web pages) have been enabled."
				echo "You must restart the Apache web server for this to take affect."
				echo " "
				fi


			######################################
			
       
         # Enable HTTP (port 80) htaccess
         #/usr/sbin/a2ensite 000-default
          
         HTTP_CONFIG="/etc/apache2/sites-available/000-default.conf"
            
            if [ ! -f $HTTP_CONFIG ]; then
            
            echo "$HTTP_CONFIG could NOT be found on your system."
            echo "Please enter the FULL Apache config file path for HTTP (port 80):"
            echo " "
            
            read HTTP_CONFIG
                    
                if [ ! -f $HTTP_CONFIG ] || [ -z "$HTTP_CONFIG" ]; then
                echo "No HTTP config file detected, skipping Apache htaccess setup for port 80..."
                SKIP_HTTP_HTACCESS=1
                else
                echo "Using Apache HTTP config file:"
                echo "$HTTP_CONFIG"
                CHECK_HTTP=$(<$HTTP_CONFIG)
                fi
            
            echo " "
            
            else
            
            CHECK_HTTP=$(<$HTTP_CONFIG)
            
            fi
            
            
            
            if [ "$SKIP_HTTP_HTACCESS" != "1" ] && [[ $CHECK_HTTP != *"cryptocoin_htaccess_80"* ]]; then
            
            echo " "
            
            echo "Enabling htaccess for HTTP (port 80)..."
            echo " "


# Don't nest / indent, or it could malform the setting addition            
read -r -d '' HTACCESS_HTTP <<- EOF
\r
\t#cryptocoin_htaccess_80
\t<Directory $DOC_ROOT>
\t\tOptions Indexes FollowSymLinks MultiViews
\t\tAllowOverride All
\t\tRequire all granted
\t</Directory>
\r
EOF
            
            
            # Backup the HTTP config before editing, to be safe
            \cp $HTTP_CONFIG $HTTP_CONFIG.BACKUP.$DATE
            
            
            # Create the new HTTP config
            NEW_HTTP_CONFIG=$(echo -e "$HTACCESS_HTTP" | /bin/sed '/:80>/r /dev/stdin' $HTTP_CONFIG)
            
            
            # Install the new HTTP config
            echo -e "$NEW_HTTP_CONFIG" > $HTTP_CONFIG
                            
                            
                # Restart Apache
                if [ -f /etc/init.d/apache2 ]; then
                echo "Htaccess has been enabled for HTTP (port 80),"
                echo "restarting the Apache web server..."
                /etc/init.d/apache2 restart
                echo " "
                else
                echo "Htaccess has been enabled for HTTP (port 80)."
                echo "You must restart the Apache web server for this to take affect."
                echo " "
                fi
            
            
            else
            
            echo " "
            
            echo "Htaccess was already enabled for HTTP (port 80)."
            echo " "
            
            fi
            
            
         ######################################
                        
                                                
         # Enable HTTPS (port 443) htaccess
         #/usr/sbin/a2ensite default-ssl
         
         
         HTTPS_CONFIG="/etc/apache2/sites-available/default-ssl.conf"
            
            if [ ! -f $HTTPS_CONFIG ]; then
            
            echo "$HTTPS_CONFIG could NOT be found on your system."
            echo "Please enter the FULL Apache config file path for HTTPS (port 443):"
            echo " "
            
            read HTTPS_CONFIG
                    
                if [ ! -f $HTTPS_CONFIG ] || [ -z "$HTTPS_CONFIG" ]; then
                echo "No HTTPS config file detected, skipping Apache htaccess setup for port 443..."
                SKIP_HTTPS_HTACCESS=1
                else
                echo "Using Apache HTTPS config file:"
                echo "$HTTPS_CONFIG"
                CHECK_HTTPS=$(<$HTTPS_CONFIG)
                fi
            
            echo " "
            
            else
            
            CHECK_HTTPS=$(<$HTTPS_CONFIG)
            
            fi
            
            
            
            if [ "$SKIP_HTTPS_HTACCESS" != "1" ] && [[ $CHECK_HTTPS != *"cryptocoin_htaccess_443"* ]]; then
            
            echo " "
            
            echo "Enabling htaccess for HTTPS (port 443)..."
            echo " "
            
            
            
# Don't nest / indent, or it could malform the setting addition  
read -r -d '' HTACCESS_HTTPS <<- EOF
\r
\t#cryptocoin_htaccess_443
\t<Directory $DOC_ROOT>
\t\tOptions Indexes FollowSymLinks MultiViews
\t\tAllowOverride All
\t\tRequire all granted
\t</Directory>
\r
EOF
            
            
            # Backup the HTTPS config before editing, to be safe
            \cp $HTTPS_CONFIG $HTTPS_CONFIG.BACKUP.$DATE
            
            
            # Create the new HTTPS config
            NEW_HTTPS_CONFIG=$(echo -e "$HTACCESS_HTTPS" | /bin/sed '/:443>/r /dev/stdin' $HTTPS_CONFIG)
            
            
            # Install the new HTTPS config
            echo -e "$NEW_HTTPS_CONFIG" > $HTTPS_CONFIG
                            
                            
                # Restart Apache
                if [ -f /etc/init.d/apache2 ]; then
                echo "Htaccess has been enabled for HTTPS (port 443),"
                echo "restarting the Apache web server..."
                /etc/init.d/apache2 restart
                echo " "
                else
                echo "Htaccess has been enabled for HTTPS (port 443)."
                echo "You must restart the Apache web server for this to take affect."
                echo " "
                fi
            
            
            else
            
            echo " "
            
            echo "Htaccess was already enabled for HTTPS (port 443)."
            echo " "
            
            fi
            

			######################################
			
			
			echo " "
			
			echo "PHP web server installation is complete."

        break
       elif [ "$opt" = "skip" ]; then
        echo " "
        echo "Skipping PHP web server setup..."
        break
       fi
done

echo " "


######################################


echo "We need to find out what user group the web server belongs to."
echo " "

echo "Attempting to auto-detect the web server's user group..."
echo " "

WWW_GROUP=$(/bin/ps -ef | /bin/egrep '(httpd|httpd2|apache|apache2)' | /bin/grep -v `whoami` | /bin/grep -v root | /usr/bin/head -n1 | /usr/bin/awk '{print $1}')

echo "The web server's user group has been detected as:"

if [ -z "$WWW_GROUP" ]; then
WWW_GROUP="www-data"
echo "User group NOT detected, using default group 'www-data'"
else
echo "$WWW_GROUP"
fi

echo " "
echo "Enter the web server's user group:"
echo "(leave blank / hit enter to use default group '$WWW_GROUP')"
echo " "

read CUSTOM_GROUP
        
if [ -z "$CUSTOM_GROUP" ]; then
CUSTOM_GROUP=${1:-$WWW_GROUP}
echo "Using default user group: $WWW_GROUP"
else
echo "Using custom user group: $CUSTOM_GROUP"
fi

echo " "
echo "The web server's user group has been declared as:"
echo "$CUSTOM_GROUP"
echo " "


######################################


echo "We need to add the username you'll be logging in as,"
echo "to the '$CUSTOM_GROUP' web server user group to allow proper editing permissions..."
echo " "

echo "Enter the system username to allow web server editing access for:"
echo "(leave blank / hit enter for default of username 'pi')"
echo " "

read SYS_USER
        
if [ -z "$SYS_USER" ]; then
SYS_USER=${1:-pi}
echo "Using default username: $SYS_USER"
else
echo "Using username: $SYS_USER"
fi

/bin/chown -R $SYS_USER:$SYS_USER /var/www/*

/usr/sbin/usermod -a -G $CUSTOM_GROUP $SYS_USER

echo " "
echo "Web server editing access for user name '$SYS_USER', in web server user group '$CUSTOM_GROUP', is completed."
echo " "


######################################


echo "Do you want this script to automatically download the latest version of"
echo "DFD Cryptocoin Values from Github.com, and install / configure it?"
echo " "

echo "Select 1 or 2 to choose whether to auto-install DFD Cryptocoin Values, or skip it."
echo " "

OPTIONS="auto_install_coin_app skip"

select opt in $OPTIONS; do
        if [ "$opt" = "auto_install_coin_app" ]; then
        
        		if [ ! -d "$DOC_ROOT" ]; then
        		
        		echo " "
				
				echo "Directory $DOC_ROOT DOES NOT exist, cannot install DFD Cryptocoin Values."
				echo "Skipping auto-install of DFD Cryptocoin Values."
				else
				
				echo " "
				
				echo "Proceeding with required component installation..."
				
				echo " "
				
				/usr/bin/apt-get install curl jq bsdtar pwgen openssl -y
				
				echo " "
				
				echo "Required component installation completed."
				
				sleep 3
				
				echo " "
				
				echo "Downloading and installing the latest version of DFD Cryptocoin Values, from Github.com..."
				
				echo " "
				
				mkdir DFD-Cryptocoin-Values
				
				cd DFD-Cryptocoin-Values
				
				ZIP_DL=$(/usr/bin/curl -s 'https://api.github.com/repos/taoteh1221/DFD_Cryptocoin_Values/releases/latest' | /usr/bin/jq -r '.zipball_url')
				
				/usr/bin/wget -O DFD-Cryptocoin-Values.zip $ZIP_DL
				
				/usr/bin/bsdtar --strip-components=1 -xvf DFD-Cryptocoin-Values.zip
				
				rm DFD-Cryptocoin-Values.zip
				
				
					if [ -f $DOC_ROOT/config.php ]; then
					
					# Generate random string 16 characters long
					RAND_STRING=$(/usr/bin/pwgen -s 16 1)
					
					
						# If pwgen fails, use openssl
						if [ -z "$RAND_STRING" ]; then
  						RAND_STRING=$(/usr/bin/openssl rand -hex 12)
						fi
				
						# If openssl fails, create manually
						if [ -z "$RAND_STRING" ]; then
						echo " "
						echo "Automatic random hash creation has failed,"
						echo "please enter a random alphanumeric string of text (no spaces / symbols) at least 10 characters long."
						echo "If you skip this, no backup of the previous install's $DOC_ROOT/config.php file will be created (for security reasons),"
						echo "and YOU WILL LOSE ALL PREVIOUSLY-CONFIGURED SETTINGS."
						echo " "
  						read RAND_STRING
						fi
				
						# If $RAND_STRING has a value, backup config.php, otherwise don't create backup file (for security reasons)
						if [ ! -z "$RAND_STRING" ]; then
  							
						cp $DOC_ROOT/config.php $DOC_ROOT/config.php.BACKUP.$DATE.$RAND_STRING
						
						/bin/chown $SYS_USER:$SYS_USER $DOC_ROOT/config.php.BACKUP.$DATE.$RAND_STRING
						
						CONFIG_BACKUP=1
						
  						else
  						echo "No backup of the previous install's $DOC_ROOT/config.php file was created (for security reasons)."
  						echo "The new install WILL NOW OVERWRITE ALL PREVIOUSLY-CONFIGURED SETTINGS in $DOC_ROOT/config.php..."
  						echo " "
						fi
						
					
  					fi
  				
  				
				# No trailing forward slash here
				\cp -r ./ $DOC_ROOT
				
				cd ../
				
				rm -rf DFD-Cryptocoin-Values
				
				rm -rf $DOC_ROOT/.github
				
				rm $DOC_ROOT/.gitattributes
				
				rm $DOC_ROOT/.gitignore
				
				/bin/chmod 777 $DOC_ROOT/cache
				
				/bin/chmod 755 $DOC_ROOT/cron.php
				
				# No trailing forward slash here
				/bin/chown -R $SYS_USER:$SYS_USER $DOC_ROOT
				
				echo " "
				
				echo "DFD Cryptocoin Values has been installed / configured."
				
	        	APP_SETUP=1
   	     	
  				fi

        break
       elif [ "$opt" = "skip" ]; then
        echo " "
        echo "Skipping auto-install of DFD Cryptocoin Values."
        break
       fi
done

echo " "


######################################


echo "If you want to use price alerts or charts, you'll need to setup a cron job for that."
echo " "

echo "Select 1 or 2 to choose whether to setup a cron job for price alerts / charts, or skip it."
echo " "

OPTIONS="auto_setup_cron skip"

select opt in $OPTIONS; do
        if [ "$opt" = "auto_setup_cron" ]; then
        
        echo " "
        echo "Enter the FULL system path to cron.php:"
        echo "(leave blank / hit enter for default of $DOC_ROOT/cron.php)"
        echo " "
        
        read PATH
        
        	if [ -z "$PATH" ]; then
			PATH=${1:-$DOC_ROOT/cron.php}
      	echo "Using default system path to cron.php:"
      	echo "$PATH"
			else
      	echo "System path set to cron.php:"
      	echo "$PATH"
			fi
        
        echo " "
        echo "Enter the time interval in minutes to run this cron job:"
        echo "(must be 5, 10, 15, 20, or 30...leave blank / hit enter for default of 15)"
        echo " "
        
        read INTERVAL
        
        	if [ -z "$INTERVAL" ]; then
			INTERVAL=${2:-15}
      	echo "Using default time interval of $INTERVAL minutes."
			else
      	echo "Time interval set to $INTERVAL minutes."
			fi
        
				
		  # Setup cron (to check logs after install: tail -f /var/log/syslog | grep cron -i)
				
		  /usr/bin/touch /etc/cron.d/cryptocoin
				
        CRONJOB="*/$INTERVAL * * * * $SYS_USER /usr/bin/php -q $PATH > /dev/null 2>&1"

		  # Play it safe and be sure their is a newline after this job entry
		  echo -e "$CRONJOB\n" > /etc/cron.d/cryptocoin
		  
		  # cron.d entries must be a permission of 644
		  /bin/chmod 644 /etc/cron.d/cryptocoin
		  
		  # cron.d entries MUST BE OWNED BY ROOT
		  /bin/chown root:root /etc/cron.d/cryptocoin
		  
        
        echo " "
        echo "A cron job has been setup for user '$SYS_USER',"
        echo "as a command in /etc/cron.d/cryptocoin:"
        echo "$CRONJOB"
        echo " "
        
        echo "IMPORTANT NOTE:"
        echo "If everything is setup properly and the cron job still does NOT run,"
        echo "your particular server may require the cron.php file permissions to be set"
        echo "as 'executable' ('755' chmod on unix / linux systems) to allow running it."
        
        CRON_SETUP=1
        
        break
       elif [ "$opt" = "skip" ]; then
        echo " "
        echo "Skipping cron job setup."
        break
       fi
done

echo " "


######################################


echo "Enabling the built-in SSH server on your system allows easy remote"
echo "installation / updating of your web site files via SFTP (from another computer"
echo "on your home / internal network), with Filezilla or any other SFTP-enabled FTP software."
echo " "

echo "If you choose to NOT enable SSH on your system, you'll need to install / update your"
echo "web site files directly on the device itself (not recommended)."
echo " "

echo "If you do use SSH, ---make sure the password for username '$SYS_USER' is strong---,"
echo "because anybody on your home / internal network will have access if they know the username/password!"
echo " "

if [ -f "/usr/bin/raspi-config" ]; then
echo "Select 1 or 2 to choose whether to setup SSH (under 'Interfacing Options' in raspi-config), or skip it."
else
echo "Select 1 or 2 to choose whether to setup SSH, or skip it."
fi

echo " "

OPTIONS="setup_ssh skip"

select opt in $OPTIONS; do
        if [ "$opt" = "setup_ssh" ]; then
        

				if [ -f "/usr/bin/raspi-config" ]; then
				echo " "
				echo "Initiating raspi-config..."
				# We need sudo here, or raspi-config fails in bash
				/usr/bin/sudo /usr/bin/raspi-config
				else
				echo " "
				
				echo "Proceeding with openssh-server installation..."
				
				echo " "
				
				/usr/bin/apt-get install openssh-server -y
				
				echo " "
				
				echo "openssh-server installation completed."
				fi
        
        
        SSH_SETUP=1
        break
       elif [ "$opt" = "skip" ]; then
        echo " "
        echo "Skipping SSH setup."
        break
       fi
done
       
echo " "


######################################


echo " "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "# SAVE THE INFORMATION BELOW FOR FUTURE ACCESS TO THIS APP #"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo " "



if [ "$APP_SETUP" = "1" ]; then

echo "Web server setup and installation / configuration of DFD Cryptocoin Values"
echo "should now be complete (if you chose those options), unless you saw any"
echo "errors on screen during setup."
echo " "

echo "DFD Cryptocoin Values is located at (and can be edited) inside this folder:"
echo "$DOC_ROOT"
echo " "

echo "You may now optionally edit the DFD Cryptocoin Values configuration file"
echo "(config.php) remotely via SFTP, or by editing app files locally."
echo " "

else

echo "Web server setup should now be complete (if you chose that option),"
echo "unless you saw any errors on screen during setup."
echo " "

echo "Web site app files must be placed inside this folder:"
echo "$DOC_ROOT"
echo " "

echo "If web server setup has completed successfully, DFD Cryptocoin Values"
echo "can now be installed (if you haven't already) in $DOC_ROOT remotely via SFTP,"
echo "or by copying over app files locally."
echo " "

fi



if [ "$CONFIG_BACKUP" = "1" ]; then

echo "The previously-installed DFD Cryptocoin Values configuration"
echo "file $DOC_ROOT/config.php has been backed up to:"
echo "$DOC_ROOT/config.php.BACKUP.$DATE.$RAND_STRING"
echo "You will need to manually move any custom settings in this backup file to the new config.php file with a text editor."
echo " "

fi



if [ "$CRON_SETUP" = "1" ]; then

echo "A cron job has been setup for user '$SYS_USER',"
echo "as a command in /etc/cron.d/cryptocoin:"
echo "$CRONJOB"
echo " "

echo "Double-check that the command 'crontab -e' does not have any OLD MATCHING entries"
echo "pointing to the same cron job, OR YOUR CRON JOB WILL RUN TOO OFTEN."
echo "(when /etc/cron.d/ is used, then 'crontab -e' should NOT BE USED for the same cron job)"
echo " "

fi



if [ "$SSH_SETUP" = "1" ]; then

echo "SFTP login details are..."
echo " "

echo "INTERNAL NETWORK SFTP host (port 22, on home / internal network):"
echo "$IP"
echo " "

echo "SFTP username: $SYS_USER"
echo "SFTP password: (password for system user $SYS_USER)"
echo " "

echo "SFTP remote working directory (where web site files should be placed on web server):"
echo "$DOC_ROOT"
echo " "

fi



echo "INTERNAL NETWORK HTTP web address (viewing web pages in web browser, on home / internal network) is:"
echo "http://$IP"
echo " "

echo "INTERNAL NETWORK SSL / HTTPS (secure / private SSL connection) web address is:"
echo "https://$IP"
echo " "

echo "IMPORTANT SSL / HTTPS NOTE:"
echo "The SSL certificate installed on this web server is SELF-SIGNED,"
echo "so your browser ---will give you a warning message--- when you visit"
echo "the above HTTPS address. This is normal behavior for self-signed"
echo "certificates, no need to get worried about it. Google search"
echo "with 'self-signed https' for more information on the topic."
echo " "

echo "If you wish to allow internet access (when not on your home / internal network),"
echo "port forwarding on your router needs to be setup (preferably with strict router firewall rules,"
echo "to disallow this device to request access to other machines on your home / internal network,"
echo "and only allow it to route outbound through the internet gateway)."
echo " "

echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"


######################################


#PHP fastCGI and suexec...not yet a good automated script, so disabled for now

#echo "https://cwiki.apache.org/confluence/display/httpd/PHP-FPM"
#echo "https://geekanddummy.com/how-to-raspberry-pi-tutorial-part-3-web-file-hosting-with-webmin-virtualmin"

#echo "Making sure your system is updated before installing required components..."
				
#/usr/bin/apt-get update
				
#/usr/bin/apt-get upgrade -y
				
#echo "Proceeding with required component installation..."

#/usr/bin/apt-get install php-fpm apache2-suexec-custom -y
				
#echo "Required component installation completed."

# Activates in Apache2 with following commands
#/usr/sbin/a2enmod proxy_fcgi setenvif
#/usr/sbin/a2enconf php7.3-fpm
#/usr/sbin/a2enmod suexec
#/usr/sbin/a2enmod actions


######################################


