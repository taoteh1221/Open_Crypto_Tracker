#!/bin/bash

rsync -vaz ~/public_html/DEV-SITE/cache/charts ~/public_html/PUBLIC-SITE/cache
