<?php
/*
 * Copyright 2014-2019 GPLv3, DFD Cryptocoin Values by Mike Kilday: http://DragonFrugal.com
 */


?>

			<div style='border: 2px dotted red; font-weight: bold; padding: 9px; color: red;'><a href='index.php' style='color: red;'>Click Here To Reset Default Tab / Tool Settings</a></div>
			
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>QR Code Generator For Addresses</b> </legend>
		    
				<?php require("app-lib/php/other/qr-code-generator/qr-code-generator.php"); ?>
				
				
			</fieldset>