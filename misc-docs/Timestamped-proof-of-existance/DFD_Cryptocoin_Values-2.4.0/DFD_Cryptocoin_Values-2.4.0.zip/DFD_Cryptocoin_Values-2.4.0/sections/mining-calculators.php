<?php
/*
 * Copyright 2014-2019 GPLv3, DFD Cryptocoin Values by Mike Kilday: http://DragonFrugal.com
 */


?>

			<div style='border: 2px dotted red; font-weight: bold; padding: 9px; color: red;'><a href='index.php' style='color: red;'>Click Here To Reset Default Tab / Calculators</a></div>
			
			<p style='font-weight: bold; color: red;'> Chain data (block height, difficulty, etc) on this page is cached for <?=$chainstats_cache?> minute(s). </p>
			
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Bitcoin Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/bitcoin-mining-calculator.php"); ?>
				
				
			</fieldset>
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Ethereum Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/ethereum-mining-calculator.php"); ?>
				
				
			</fieldset>
				
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Monero Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/monero-mining-calculator.php"); ?>
				
				
			</fieldset>
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Litecoin Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/litecoin-mining-calculator.php"); ?>
				
				
			</fieldset>
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Decred Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/decred-mining-calculator.php"); ?>
				
				
			</fieldset>
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>Ravencoin Mining Calculator</b> </legend>
		    
				<?php require("app-lib/php/other/calculators/ravencoin-mining-calculator.php"); ?>
				
				
			</fieldset>
			
			<fieldset class='blue_fieldset'>
				<legend style='color: blue;'> <b>STEEM Power Interest Rate / Power Down Weekly Payout Calculator</b> </legend>
				
				<?php require("app-lib/php/other/calculators/steem-power-interest-calculator.php"); ?>
				
			</fieldset>
		    