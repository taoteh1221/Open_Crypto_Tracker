<?php
/*
 * Copyright 2014-2019 GPLv3, DFD Cryptocoin Values by Mike Kilday: http://DragonFrugal.com
 */
 
require_once("app-lib/php/functions/general.php");
require_once("app-lib/php/functions/coin-data.php");
require_once("app-lib/php/functions/exchange-api.php");
require_once("app-lib/php/functions/other-api.php");


?>